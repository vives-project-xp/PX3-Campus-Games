<template>
    <div>
      <h2>Scan QR Code</h2>
      <video ref="video" width="400" autoplay></video>
      <canvas ref="canvas" hidden></canvas>
      <p v-if="qrCodeData">QR Code Result: {{ qrCodeData }}</p>
    </div>
  </template>
  
  <script>
  import jsQR from "jsqr";
  
  export default {
    data() {
      return {
        qrCodeData: null,  // Store the decoded QR code data
      };
    },
    mounted() {
      this.startCamera();
    },
    methods: {
      // Access the camera and start scanning
      startCamera() {
        navigator.mediaDevices
          .getUserMedia({ video: { facingMode: "environment" } })
          .then((stream) => {
            const video = this.$refs.video;
            video.srcObject = stream;
            video.setAttribute("playsinline", true); // For iOS
            video.play();
            this.scanQRCode();
          })
          .catch((err) => {
            console.error("Error accessing camera: ", err);
          });
      },
  
      // Function to continuously scan the QR code
      scanQRCode() {
        const video = this.$refs.video;
        const canvas = this.$refs.canvas;
        const context = canvas.getContext("2d");
  
        // Check if the video stream is available
        if (video.readyState === video.HAVE_ENOUGH_DATA) {
          canvas.height = video.videoHeight;
          canvas.width = video.videoWidth;
          context.drawImage(video, 0, 0, canvas.width, canvas.height);
  
          // Get image data from the canvas and try to decode the QR code
          const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
          const code = jsQR(imageData.data, canvas.width, canvas.height);
  
          if (code) {
            this.qrCodeData = code.data;  // Store the QR code data
            
            // Send the QR code data to the backend
            this.sendQRCodeToBackend(code.data);
          }
        }
  
        // Continue scanning
        requestAnimationFrame(this.scanQRCode);
      },
  
      // Send the QR code data to the backend
      sendQRCodeToBackend(qrCode) {
        fetch("/process-qr-code", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ qrCode }),
        })
          .then((response) => response.json())
          .then((data) => {
            console.log("Backend response:", data);
          })
          .catch((err) => {
            console.error("Error sending QR code data to backend:", err);
          });
      },
    },
  };
  </script>
  
  <style scoped>
  video {
    border: 1px solid black;
  }
  </style>
  