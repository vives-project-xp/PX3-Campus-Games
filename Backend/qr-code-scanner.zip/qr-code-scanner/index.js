const express = require("express");
const bodyParser = require("body-parser");

const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.json());

// Route to handle QR code data
app.post("/process-qr-code", (req, res) => {
  const qrCodeData = req.body.qrCode;
  console.log("Received QR code data:", qrCodeData);
  // You can process the data here or store it in a database

  // Send a response back to the frontend
  res.json({ message: "QR code processed successfully!", data: qrCodeData });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
